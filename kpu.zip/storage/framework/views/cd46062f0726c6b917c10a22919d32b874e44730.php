<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Laporan Surat Keluar</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active">Surat Keluar</li>
                    <li class="breadcrumb-item">Laporan Surat Keluar</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">
                        <div class="form-row mt-4">
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Awal </label>
                                <input class=" form-control" min="2022-01-01" name="awalkeluar" id="awalkeluar"
                                    type="date" />
                            </div>
                            <div class="col-6 col-sm-6">
                                <label>Tanggal Akhir</label>
                                <input class=" form-control" min="2022-01-01" name="akhirkeluar" id="akhirkeluar"
                                    type="date" />
                            </div>
                        </div>
                        <div class="input-group" style="margin-top: 5px">
                            <a href="#" onclick="this.href='/rekap/surat/keluar/'+document.getElementById('awalkeluar').value +
                                '/' + document.getElementById('akhirkeluar').value" target="_blank"
                                class="btn btn-primary">Cetak
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\2 digitalisasi arsip surat masuk dan surat keluar pada sekretariat kpu kota jambi\PENGEMBANGAN\KPU\resources\views/skeluar/rekap.blade.php ENDPATH**/ ?>