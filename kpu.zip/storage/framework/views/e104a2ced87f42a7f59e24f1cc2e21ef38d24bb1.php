<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h5 class="mt-1">
                <font color="black"><b>SISTEM INFORMASI PENGARSIPAN SURAT MASUK DAN SURAT KELUAR KPU KOTA JAMBI</b></font>
            </h5>
            <ol class="breadcrumb mb-1">
                <?php if(auth()->user()->role == 'Admin'): ?>
                    <li class="breadcrumb-item">Selamat Datang <?php echo e(Auth::user()->name); ?></li>
                <?php endif; ?>
                <?php if(auth()->user()->role == 'Bidang'): ?>
                    <li class="breadcrumb-item">Selamat Datang <?php echo e(Auth::user()->name); ?></li>
                <?php endif; ?>
                <?php if(auth()->user()->role == 'Ketua'): ?>
                    <li class="breadcrumb-item">Selamat Datang Ketua KPU Kota Jambi</li>
                <?php endif; ?>
                <?php if(auth()->user()->role == 'Sekretaris'): ?>
                    <li class="breadcrumb-item">Selamat Datang Sekretaris KPU Kota Jambi</li>
                <?php endif; ?>
            </ol>
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <div class="card mb-4">
                <div class="card-body">
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-md-12">

                                <?php if(auth()->user()->role == 'Admin'): ?>
                                    <div class="row">
                                        <!-- Masuk -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/masuk', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                                                    Surat Masuk
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($amasuk); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Keluar -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/keluar', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                                    Surat Keluar
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($akeluar); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope-open fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->role == 'Bidang'): ?>
                                    <div class="row">
                                        <!-- Masuk -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/bidang/surat/masuk', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                                                    Surat Masuk
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($masuk); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Keluar -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/bidang/surat/keluar', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                                    Surat Keluar
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($keluar); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope-open fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->role == 'Ketua'): ?>
                                    <div class="row">
                                        <!-- Masuk -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/masuk', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                                                    Surat Masuk
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($ksmasuk); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Keluar -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/keluar', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                                    Surat Keluar
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($kskeluar); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope-open fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <?php if(auth()->user()->role == 'Sekretaris'): ?>
                                    <div class="row">
                                        <!-- Masuk -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/masuk', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-secondary text-uppercase mb-1">
                                                                    Surat Masuk
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($ksmasuk); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                        <!-- Keluar -->
                                        <div class="col-xl-4 col-md-6 mb-4">
                                            <div class="card border-left-info shadow h-100 py-2">
                                                <div class="card-body">
                                                    <a href="<?php echo e(url('/surat/keluar', [])); ?>">
                                                        <div class="row no-gutters align-items-center">
                                                            <div class="col mr-2">
                                                                <div
                                                                    class="text-xs font-weight-bold text-success text-uppercase mb-1">
                                                                    Surat Keluar
                                                                </div>
                                                                <div class="row no-gutters align-items-center">
                                                                    <div class="col-auto">
                                                                        <div
                                                                            class="h5 mb-0 mr-3 font-weight-bold text-gray-800">
                                                                            <?php echo json_encode($kskeluar); ?></div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            <div class="col-auto">
                                                                <i class="fas fa-envelope-open fa-2x text-gray-300"></i>
                                                            </div>
                                                        </div>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\pengembangan\KPU\resources\views/home.blade.php ENDPATH**/ ?>