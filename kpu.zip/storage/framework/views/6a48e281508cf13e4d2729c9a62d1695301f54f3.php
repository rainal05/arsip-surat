<?php $__env->startSection('content'); ?>
<?php if(auth()->user()->role == 'Admin'): ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Surat Keluar</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active"><a href="#" data-toggle="modal" data-target="#exampleModal">
                    Tambah Surat</a>
                </li>
                <li class="breadcrumb-item"><a href="#" data-toggle="modal" data-target="#exampleModal"> <i class="fa fa-plus-circle" aria-hidden="true"></i></a></li>
            </ol>
            <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
            <!-- notif -->
            <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Tujuan</th>
                                    <th>Dari Bidang</th>
                                    
                                    <th>Tanggal Keluar</th>
                                    
                                    <th>Perihal</th>
                                    <th width="10%">Pilihan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->tujuan); ?></td>
                                    <td><?php echo e($item->user->name ??' - Data Bidang Telah DiHapus -'); ?></td>
                                    <td><?= Date('d-m-Y', strtotime ($item->tgl_keluar ??'' ));?></td>
                                    <td><a href="<?php echo e(url('/surat_keluar/'.$item->file ??'ss' )); ?>" target="_blank"><?php echo e($item->hal); ?> <i class="fa fa-download"></i></a></td>
                                    <td nowrap>
                                        <a href="/surat/keluar/detail/<?php echo e($item->id); ?>" class="btn btn-info btn-sm">
                                            <i class="fa fa-info-circle"></i> Detail
                                        </a>
                                        <a href="/surat/keluar/edit/<?php echo e($item->id); ?>" class="btn btn-warning btn-sm">
                                            <i class="fa fa-edit"></i> Edit
                                        </a>
                                        <a href="/surat/keluar/<?php echo e($item->id); ?>/delete" class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin ingin menghapus ?')">
                                            <i class="fa fa-trash" aria-hidden="true"></i> Hapus
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <!-- Modal tambah -->
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Tambah Data Surat Keluar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo e(url('/surat/keluar/store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-row">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Dari Bidang</label>
                                <select name="user_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Tujuan Surat</label>
                                <input type="text" name="tujuan" class="form-control" placeholder="Tujuan Surat">
                            </div>
                        </div>
                        <div class="form-row mt-3">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Tanggal Surat</label>
                                <input type="date" name="tgl_surat" class="form-control">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Tanggal Surat Keluar</label>
                                <input type="date" name="tgl_keluar" class="form-control">
                            </div>
                        </div>
                        <div class="form-row mt-3">
                            <div class="col-12 col-sm-12">
                                <label for="inputEmailAddress">No Surat</label>
                                <input type="text" name="no" class="form-control" placeholder="No Surat Masuk" >
                            </div>
                        </div>
                        <div class="form-row mt-3">
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Perihal</label>
                                <input type="text" name="hal" class="form-control" placeholder="Perihal Surat">
                            </div>
                            <div class="col-6 col-sm-6">
                                <label for="inputEmailAddress">Upload File</label>
                                <input type="file" name="file"  class="form-control">
                            </div>
                        </div>
                        <label class="form-label">
                            <span class="badge border-dark border-1 text-dark"><i>Note : Scan File Surat Dan Upload Dalam Bentuk PDF</i></span>
                        </label>
                        <div class="text-center">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                            <button type="reset" class="btn btn-secondary">Reset</button>
                        </div>
                    </form>

                </div>
            </div>
            </div>
        </div>
    
<?php endif; ?>

<?php if(auth()->user()->role == 'Bidang'): ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Surat Keluar</h1>
            <ol class="breadcrumb mb-4">
            <li class="breadcrumb-item active">Bidang</li>
            <li class="breadcrumb-item ">Surat Keluar</li>
            </ol>
            <div class="card mb-4">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th width="5%">No</th>
                                    <th>Tujuan</th>
                                    <!-- <th>Tujuan</th> -->
                                    
                                    <th>Tanggal Keluar</th>
                                    
                                    <th>Perihal</th>
                                    <th width="5%">Detail</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e($item->tujuan); ?></td>
                                    <td><?= Date('d-m-Y', strtotime ($item->tgl_keluar ??'' ));?></td>
                                    
                                    <td><a href="<?php echo e(url('/surat_keluar/'.$item->file ??'ss' )); ?>" target="_blank"><?php echo e($item->hal); ?> <i class="fa fa-download"></i></a></td>
                                    <td nowrap>
                                        <a href="/bidang/surat/keluar/detail/<?php echo e($item->id); ?>" class="btn btn-info btn-sm">
                                            <i class="fa fa-info-circle"></i> Detail
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\KPU\resources\views/skeluar/index.blade.php ENDPATH**/ ?>