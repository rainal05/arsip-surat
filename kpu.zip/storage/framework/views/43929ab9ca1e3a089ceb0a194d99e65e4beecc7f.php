<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Edit Disposisi</h1>
                <ol class="breadcrumb mb-4"> 
                    <li class="breadcrumb-item">Edit Disposisi</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">

                        <form action="/surat/masuk/disposisi/<?php echo e($dispos->id); ?>/update" method="POST"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>No Surat</b></label>
                                    <input type="text" name="no" class="form-control" value="<?php echo e($dispos->no); ?>"
                                        disabled >
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Perihal Surat</b></label>
                                    <input type="text" name="hal" class="form-control" value="<?php echo e($dispos->hal); ?>"
                                        disabled>
                                </div>
                            </div>
                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Diteruskan</b></label>
                                    <select name="user_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                            <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Sifat</b></label>
                                    <select name="sifat" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <option value="Biasa">Biasa</option>
                                        <option value="Mendesak">Mendesak</option>
                                        <option value="Perlu Perhatian Khusus">Perlu Perhatian Khusus</option>
                                        <option value="Perlu Perhatian Batas Waktu">Perlu Perhatian Batas Waktu</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Mohon Bantuan Saudara Untuk</b></label>
                                    <select name="keperluan_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $kep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Disposisi Dari</b></label>
                                    <select name="ket_sek" class="multisteps-form__select form-control">
                                    <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $pim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>    
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress"><b>Catatan</b></label>
                                    <textarea name="catat" cols="30" rows="3" class="form-control"><?php echo e($dispos->catat); ?></textarea>
                                </div>
                            </div> 
                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-success">Update</button>
                                
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
    <?php if(auth()->user()->role == 'Ketua'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Edit Disposisi</h1>
                <ol class="breadcrumb mb-4"> 
                    <li class="breadcrumb-item">Edit Disposisi</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">

                        <form action="/surat/masuk/disposisi/<?php echo e($dispos->id); ?>/update" method="POST"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="ket_sek" value="<?php echo e(Auth::user()->name); ?>">
                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>No Surat</b></label>
                                    <input type="text" name="no" class="form-control" value="<?php echo e($dispos->no); ?>"
                                        disabled >
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Perihal Surat</b></label>
                                    <input type="text" name="hal" class="form-control" value="<?php echo e($dispos->hal); ?>"
                                        disabled>
                                </div>
                            </div>
                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Diteruskan</b></label>
                                    <select name="user_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                            <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Sifat</b></label>
                                    <select name="sifat" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <option value="Biasa">Biasa</option>
                                        <option value="Mendesak">Mendesak</option>
                                        <option value="Perlu Perhatian Khusus">Perlu Perhatian Khusus</option>
                                        <option value="Perlu Perhatian Batas Waktu">Perlu Perhatian Batas Waktu</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress"><b>Mohon Bantuan Saudara Untuk</b></label>
                                    <select name="keperluan_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $kep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                            </div>    
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress"><b>Catatan</b></label>
                                    <textarea name="catat" cols="30" rows="3" class="form-control"><?php echo e($dispos->catat); ?></textarea>
                                </div>
                            </div> 
                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-success">Update</button>
                                
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
    <?php if(auth()->user()->role == 'Sekretaris'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Edit Disposisi</h1>
                <ol class="breadcrumb mb-4"> 
                    <li class="breadcrumb-item">Edit Disposisi</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">

                        <form action="/surat/masuk/disposisi/<?php echo e($dispos->id); ?>/update" method="POST"
                            enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="ket_sek" value="<?php echo e(Auth::user()->name); ?>">
                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>No Surat</b></label>
                                    <input type="text" name="no" class="form-control" value="<?php echo e($dispos->no); ?>"
                                        disabled >
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Perihal Surat</b></label>
                                    <input type="text" name="hal" class="form-control" value="<?php echo e($dispos->hal); ?>"
                                        disabled>
                                </div>
                            </div>
                            <div class="form-row mt-3"> 
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Diteruskan</b></label>
                                    <select name="user_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                            <?php $__currentLoopData = $sub; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Sifat</b></label>
                                    <select name="sifat" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <option value="Biasa">Biasa</option>
                                        <option value="Mendesak">Mendesak</option>
                                        <option value="Perlu Perhatian Khusus">Perlu Perhatian Khusus</option>
                                        <option value="Perlu Perhatian Batas Waktu">Perlu Perhatian Batas Waktu</option>
                                    </select>
                                </div>
                            </div> 
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress"><b>Mohon Bantuan Saudara Untuk</b></label>
                                    <select name="keperluan_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $kep; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                
                            </div>    
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress"><b>Catatan</b></label>
                                    <textarea name="catat" cols="30" rows="3" class="form-control"><?php echo e($dispos->catat); ?></textarea>
                                </div>
                            </div> 
                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-success">Update</button>
                                
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\2 digitalisasi arsip surat masuk dan surat keluar pada sekretariat kpu kota jambi\KPU\resources\views/smasuk/disposisi-edit.blade.php ENDPATH**/ ?>