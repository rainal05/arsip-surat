<?php $__env->startSection('content'); ?>
    <main>
        <div class="container-fluid">
            <h1 class="mt-4">Profil</h1>
            <ol class="breadcrumb mb-4">
                <li class="breadcrumb-item active">Profil Saya
                </li>
            </ol>
            <!-- notif -->
            <?php if(\Session::has('notif')): ?>
                <div class="alert alert-primary" align="center">
                    <?php echo \Session::get('notif'); ?>

                </div>
            <?php endif; ?>
            <!-- notif -->
            <!-- error -->
            <?php if(count($errors) > 0): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <!-- end error -->
            <div class="card mb-4">
                <div class="card-body">
                    <table class="table table-sm table-stripped">
                        <tbody>
                            <?php $__currentLoopData = $profil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td colspan="2">
                                        <h4 class="text-success">Data Diri Akun, <?php echo e($item->name); ?>

                                            <a href="profile/<?php echo e($item->id); ?>/"><i class="fa fa-edit"></i></a>
                                        </h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Username</td>
                                    <td>: <?php echo e($item->username); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">No Wa</td>
                                    <td>: <a href="https://wa.me/<?php echo e($item->wa); ?>" target="_blank">
                                            <?php echo e($item->wa); ?>

                                        </a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\pengembangan\KPU\resources\views/profil/index.blade.php ENDPATH**/ ?>