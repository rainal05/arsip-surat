<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Edit Surat Masuk</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/surat/masuk')); ?>">Surat Masuk</a></li>
                    <li class="breadcrumb-item">Edit Surat Masuk</li>
                </ol>
                <!-- notif -->
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <!-- notif -->
                <!-- error -->
                <?php if(count($errors) > 0): ?>
                    <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <!-- end error -->
                <div class="card mb-4">
                    <div class="card-body">

                        <form action="/surat/masuk/<?php echo e($masuk->id); ?>/update" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-row">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Dari</b></label>
                                    <input type="text" name="dari" class="form-control" value="<?php echo e($masuk->dari); ?>"
                                        placeholder="Surat Dari">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Tujuan</b></label>
                                    <select name="user_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $pim; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Tanggal Surat</b></label>
                                    <input type="date" name="tgl_surat" value="<?php echo e($masuk->tgl_surat); ?>"
                                        class="form-control">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Tanggal Surat Masuk</b></label>
                                    <input type="date" name="tgl_masuk" value="<?php echo e($masuk->tgl_masuk); ?>"
                                        class="form-control">
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>No Surat</b></label>
                                    <input type="text" name="no" class="form-control" value="<?php echo e($masuk->no); ?>"
                                        placeholder="No Surat Masuk">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Kode Surat</b></label>
                                    <select name="kode_id" class="multisteps-form__select form-control">
                                        <option value="">-- PILIH --</option>
                                        <?php $__currentLoopData = $kode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->kode); ?> | <?php echo e($item->nama); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Perihal</b></label>
                                    <input type="text" name="hal" class="form-control" value="<?php echo e($masuk->hal); ?>"
                                        placeholder="Perihal Surat">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress"><b>Upload File</b></label>
                                    <input type="file" name="file" class="form-control">
                                </div>
                            </div>
                            <label class="form-label">
                                <span class="badge border-dark border-1 text-dark"><i>Note : Scan File Surat Dan Upload
                                        Dalam Bentuk PDF</i></span>
                            </label>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success">Update</button>
                                
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\2 digitalisasi arsip surat masuk dan surat keluar pada sekretariat kpu kota jambi\PENGEMBANGAN\KPU\resources\views/smasuk/edit.blade.php ENDPATH**/ ?>