<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Detail Surat Keluar</h1>
        <ol class="breadcrumb mb-4">
            <?php if(auth()->user()->role == 'Admin'): ?>
                <li class="breadcrumb-item active"><a href="<?php echo e(url('/surat/keluar')); ?>">Surat Keluar</a></li>
                <li class="breadcrumb-item">Detail Surat Keluar</li>
            <?php endif; ?>
            <?php if(auth()->user()->role == 'Bidang'): ?>
                <li class="breadcrumb-item active"><a href="<?php echo e(url('/bidang/surat/keluar')); ?>">Surat Keluar</a></li>
                <li class="breadcrumb-item">Detail Surat Keluar</li>
            <?php endif; ?>
        </ol>
        <?php if(\Session::has('notif')): ?>
            <div class="alert alert-primary" align="center">
                <?php echo \Session::get('notif'); ?>

            </div>
        <?php endif; ?>
        <div class="card mb-4">
            <div class="card-body">
                <table class="table table-sm table-stripped">
                    <tbody>
                        <tr>
                            <td colspan="2"><h4 class="text-primary">Surat Keluar Dari Bidang <?php echo e($keluar->user->name ??' - Data Bidang Telah DiHapus -'); ?></h4></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Tujuan</td>
                            <td>: <?php echo e($keluar->tujuan); ?></td>
                        </tr>
                        <tr>
                            <td width="22%" class="font-weight-bold">No. Surat</td>
                            <td>: <?php echo e($keluar->no); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Tanggal Surat</td>
                            <td>: <?= Date('d-m-Y', strtotime ($keluar->tgl_surat ??'' ));?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Tanggal Keluar</td>
                            <td>: <?= Date('d-m-Y', strtotime ($keluar->tgl_keluar ??'' ));?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">Perihal</td>
                            <td>: <?php echo e($keluar->hal); ?></td>
                        </tr>
                        <tr>
                            <td class="font-weight-bold">File Surat</td>
                            <td>: <a href="<?php echo e(url('/surat_keluar/'.$keluar->file ??'ss' )); ?>" target="_blank">View <i class="fa fa-download"></i></a></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\KPU\resources\views/skeluar/detail.blade.php ENDPATH**/ ?>