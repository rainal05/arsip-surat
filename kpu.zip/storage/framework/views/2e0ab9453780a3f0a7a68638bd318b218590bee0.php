<?php $__env->startSection('content'); ?>
    <div class="container" id="log">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-lg border-0 rounded-lg">
                    
                    <div style="margin-top: 10px" align="center">
                        <img id="profile-img" height="180" width="150" class="profile-img-card"
                            src="https://seeklogo.com/images/K/komisi-pemilihan-umum-ri-logo-61304C4A3C-seeklogo.com.png" />
                        <p class="mt-2"><strong>SISTEM INFORMASI PENGARSIPAN SURAT MASUK SURAT KELUAR KPU KOTA
                                JAMBI</strong></p>
                    </div>
                    
                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group row">
                                <label for="username" class="col-md-4 col-form-label text-md-right">Username</label>

                                <div class="col-md-6">
                                    <input type="text"
                                        class="form-control <?php echo e($errors->has('username') || $errors->has('email') ? 'is-invalid' : ''); ?>"
                                        name="login" value="<?php echo e(old('username') ? old('username') : old('email')); ?>"
                                        placeholder="Username" />
                                    <?php if($errors->has('username') || $errors->has('email')): ?>
                                        <span class="invalid-feedback">
                                            <strong><?php echo e($errors->first('username') ? $errors->first('username') : $errors->first('email')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="password"
                                    class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>

                                <div class="col-md-6">
                                    <input id="password" type="password"
                                        class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password"
                                        required autocomplete="current-password">

                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>

                            
                            

                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Login')); ?>

                                    </button>

                                    
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RAIN\pengembangan\KPU\resources\views/auth/login.blade.php ENDPATH**/ ?>