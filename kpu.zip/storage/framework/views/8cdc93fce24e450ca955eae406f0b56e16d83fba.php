<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Edit Surat Masuk</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/surat/masuk')); ?>">Surat Masuk</a></li>
                    <li class="breadcrumb-item">Edit Surat Masuk</li>
                </ol>
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <div class="card mb-4">
                    <div class="card-body">

                        <form action="/surat/masuk/<?php echo e($masuk->id); ?>/update" method="POST" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="form-row">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress">Pengirim</label>
                                    <input type="text" name="dari" class="form-control" value="<?php echo e($masuk->dari); ?>"
                                        placeholder="Surat Dari">
                                </div>

                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Disposisi</label>
                                    <select name="user_id" class="multisteps-form__select form-control">
                                        
                                        <?php $__currentLoopData = $masuk->disposisi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->user->id); ?>"><?php echo e($item->user->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Sifat</label>
                                    <select name="sifat" class="multisteps-form__select form-control">
                                        <option value="Biasa" <?php if($masuk->sifat == 'Biasa'): ?> selected <?php endif; ?>>
                                            Biasa
                                        </option>
                                        <option value="Mendesak" <?php if($masuk->sifat == 'Mendesak'): ?> selected <?php endif; ?>>
                                            Mendesak
                                        </option>
                                        <option value="Perlu Perhatian Khusus"
                                            <?php if($masuk->sifat == 'Perlu Perhatian Khusus'): ?> selected <?php endif; ?>>
                                            Perlu Perhatian Khusus
                                        </option>
                                        <option value="Perlu Perhatian Batas Waktu"
                                            <?php if($masuk->sifat == 'Perlu Perhatian Batas Waktu'): ?> selected <?php endif; ?>>
                                            Perlu Perhatian Batas Waktu
                                        </option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Tanggal Surat</label>
                                    <input type="date" name="tgl_surat" value="<?php echo e($masuk->tgl_surat); ?>"
                                        class="form-control">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Tanggal Surat Masuk</label>
                                    <input type="date" name="tgl_masuk" value="<?php echo e($masuk->tgl_masuk); ?>"
                                        class="form-control">
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-12 col-sm-12">
                                    <label for="inputEmailAddress">No Surat</label>
                                    <input type="text" name="no" class="form-control" value="<?php echo e($masuk->no); ?>"
                                        placeholder="No Surat Masuk">
                                </div>
                            </div>
                            <div class="form-row mt-3">
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Perihal</label>
                                    <input type="text" name="hal" class="form-control" value="<?php echo e($masuk->hal); ?>"
                                        placeholder="Perihal Surat">
                                </div>
                                <div class="col-6 col-sm-6">
                                    <label for="inputEmailAddress">Upload File</label>
                                    <input type="file" name="file" class="form-control">
                                </div>
                            </div>
                            <label class="form-label">
                                <span class="badge border-dark border-1 text-dark"><i>Note : Scan File Surat Dan Upload
                                        Dalam Bentuk PDF</i></span>
                            </label>
                            <div class="text-center">
                                <button type="submit" class="btn btn-success">Update</button>
                                
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\KPU\resources\views/smasuk/edit.blade.php ENDPATH**/ ?>