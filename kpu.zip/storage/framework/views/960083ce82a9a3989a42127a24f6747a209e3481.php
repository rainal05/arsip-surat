<?php $__env->startSection('content'); ?>
    <?php if(auth()->user()->role == 'Admin'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Detail Surat Masuk</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/surat/masuk')); ?>">Surat Masuk</a></li>
                    <li class="breadcrumb-item">Detail Surat Masuk</li>
                </ol>
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <div class="card mb-4">
                    <div class="card-body">
                        <table class="table table-sm table-stripped">
                            <tbody>
                                <tr>
                                    <td colspan="2">
                                        <h4 class="text-primary">Surat Masuk Dari <?php echo e($masuk->dari); ?></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">No Agenda</td>
                                    <td>: <?php echo e($masuk->agenda ?? '- Data Hilang -'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tujuan</td>
                                    <td>: <?php echo e($masuk->user->name ?? '- Data Hilang -'); ?></td>
                                </tr>
                                <tr>
                                    <td width="22%" class="font-weight-bold">No. Surat</td>
                                    <td>: <?php echo e($masuk->no); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tanggal Surat</td>
                                    <td>: <?= Date('d-m-Y', strtotime($masuk->tgl_surat ?? '')) ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tanggal Masuk</td>
                                    <td>: <?= Date('d-m-Y', strtotime($masuk->tgl_masuk ?? '')) ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">File Surat</td>
                                    <td>: <a href="<?php echo e(url('/surat_masuk/' . $masuk->file ?? 'ss')); ?>"
                                            target="_blank"><?php echo e($masuk->hal); ?>

                                            <i class="fa fa-download"></i></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
    <?php if(auth()->user()->role == 'Bidang'): ?>
        <main>
            <div class="container-fluid">
                <h1 class="mt-4">Detail Surat Masuk</h1>
                <ol class="breadcrumb mb-4">
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('/bidang/surat/masuk')); ?>">Surat Masuk</a></li>
                    <li class="breadcrumb-item">Detail Surat Masuk</li>
                </ol>
                <?php if(\Session::has('notif')): ?>
                    <div class="alert alert-primary" align="center">
                        <?php echo \Session::get('notif'); ?>

                    </div>
                <?php endif; ?>
                <div class="card mb-4">
                    <div class="card-body">
                        <table class="table table-sm table-stripped">
                            <tbody>
                                <tr>
                                    <td colspan="2">
                                        <h4 class="text-primary">Surat Masuk Dari <?php echo e($masuk->dari); ?></h4>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Disposisi Dari</td>
                                    <td>: <?php echo e($masuk->ket_sek ?? '-Data Hilang-'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">No Agenda</td>
                                    <td>: <?php echo e($masuk->agenda ?? '-Data Hilang-'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tujuan</td>
                                    <td>: <?php echo e($masuk->user->name ?? '- Data Hilang -'); ?></td>
                                </tr>
                                <tr>
                                    <td width="22%" class="font-weight-bold">No. Surat</td>
                                    <td>: <?php echo e($masuk->no); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tanggal Surat</td>
                                    <td>: <?= Date('d-m-Y', strtotime($masuk->tgl_surat ?? '')) ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Tanggal Masuk</td>
                                    <td>: <?= Date('d-m-Y', strtotime($masuk->tgl_masuk ?? '')) ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Sifat</td>
                                    <td>: <?php echo e($masuk->sifat ?? '- Data Hilang -'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">Catatan</td>
                                    <td>: <?php echo e($masuk->catat ?? '- Data Hilang -'); ?></td>
                                </tr>
                                <tr>
                                    <td class="font-weight-bold">File Surat</td>
                                    <td>: <a href="<?php echo e(url('/surat_masuk/' . $masuk->file ?? 'ss')); ?>" target="_blank">
                                            <?php echo e($masuk->hal); ?>

                                            <i class="fa fa-download"></i></a></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\JOB SKRIPSI - KP\2 digitalisasi arsip surat masuk dan surat keluar pada sekretariat kpu kota jambi\KPU\resources\views/smasuk/detail.blade.php ENDPATH**/ ?>