<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Kode extends Model
{
    protected $guarded = [];
}
